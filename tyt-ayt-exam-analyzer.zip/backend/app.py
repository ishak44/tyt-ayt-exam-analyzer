from flask import Flask, request, jsonify, send_from_directory
import os
from werkzeug.utils import secure_filename
from config import Config
from models import db, Exam, ExamFile, Submission
from auth import auth_bp
from process_pdf import extract_answers_from_pdf

app = Flask(__name__)
app.config.from_object(Config)
db.init_app(app)
app.register_blueprint(auth_bp, url_prefix='/api/auth')

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

@app.route('/api/exams', methods=['POST'])
def create_exam():
    title = request.form.get('title')
    class_id = request.form.get('class_id')
    pdf = request.files.get('file')
    if not pdf:
        return jsonify({'error': 'PDF gerekli'}), 400
    filename = secure_filename(pdf.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    pdf.save(filepath)
    exam = Exam(title=title, class_id=class_id, uploaded_by=None)
    db.session.add(exam)
    db.session.commit()
    ef = ExamFile(exam_id=exam.id, filename=filename, filepath=filepath)
    db.session.add(ef)
    db.session.commit()
    return jsonify({'exam_id': exam.id, 'status':'uploaded'}), 201

@app.route('/api/exams', methods=['GET'])
def list_exams():
    exams = Exam.query.order_by(Exam.date.desc()).all()
    return jsonify([{'id':e.id, 'title': e.title, 'class_id': e.class_id, 'date': e.date.isoformat()} for e in exams])

@app.route('/api/exams/<int:exam_id>/process', methods=['POST'])
def process_exam(exam_id):
    ef = ExamFile.query.filter_by(exam_id=exam_id).first()
    if not ef:
        return jsonify({'error':'exam file not found'}), 404
    template = request.args.get('template', 'tyt_standard_A')
    results = extract_answers_from_pdf(ef.filepath, template_name=template)
    subs = []
    for idx, page in enumerate(results):
        sub = Submission(exam_id=exam_id, student_id=None, raw=page, score=None)
        db.session.add(sub)
        db.session.commit()
        subs.append({'submission_id': sub.id, 'page': idx})
    return jsonify({'processed_pages': len(results), 'submissions': subs})

@app.route('/uploads/<path:filename>', methods=['GET'])
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
