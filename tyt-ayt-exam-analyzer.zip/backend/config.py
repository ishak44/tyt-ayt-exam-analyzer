import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

class Config:
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or         'sqlite:///' + os.path.join(BASE_DIR, 'db.sqlite3')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    UPLOAD_FOLDER = os.environ.get('UPLOAD_FOLDER') or os.path.join(BASE_DIR, 'uploads')
    JWT_SECRET = os.environ.get('JWT_SECRET') or 'change_this_secret_in_prod'
    JWT_EXP_DELTA_HOURS = int(os.environ.get('JWT_EXP_DELTA_HOURS') or 8)
