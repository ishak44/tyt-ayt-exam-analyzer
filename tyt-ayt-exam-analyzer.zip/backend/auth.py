from flask import Blueprint, request, jsonify, current_app
import jwt, datetime
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, User

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.json
    if not data.get('email') or not data.get('password'):
        return jsonify({'error':'email and password required'}), 400
    if User.query.filter_by(email=data['email']).first():
        return jsonify({'error':'user exists'}), 400
    u = User(name=data.get('name'), email=data['email'],
             password_hash=generate_password_hash(data['password']),
             role=data.get('role','teacher'))
    db.session.add(u)
    db.session.commit()
    return jsonify({'msg':'created'}), 201

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.json
    u = User.query.filter_by(email=data.get('email')).first()
    if not u: return jsonify({'error':'no user'}), 401
    if not check_password_hash(u.password_hash, data.get('password')):
        return jsonify({'error':'invalid credentials'}), 401
    payload = {'user_id': u.id, 'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=8)}
    token = jwt.encode(payload, current_app.config['JWT_SECRET'], algorithm='HS256')
    return jsonify({'token': token})
