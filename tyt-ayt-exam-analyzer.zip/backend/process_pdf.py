# Basit template-tabanlı bubble sheet çözümleyici
# Not: Gerçek dünya kullanımı için template koordinatlarını tarama çözünürlüğüne göre ayarlayın.
import json, os
from pdf2image import convert_from_path
import numpy as np
import cv2

THRESH_FILL = 0.45

def load_template(name='tyt_standard_A'):
    p = os.path.join(os.path.dirname(__file__), '..', 'templates', f'{name}.json')
    with open(p, 'r', encoding='utf-8') as f:
        return json.load(f)

def pdf_to_images(path, dpi=300):
    return convert_from_path(path, dpi=dpi)

def pil_to_cv2(pil_img):
    arr = np.array(pil_img)
    if arr.ndim == 3:
        arr = cv2.cvtColor(arr, cv2.COLOR_RGB2BGR)
    return arr

def preprocess(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5,5), 0)
    th = cv2.adaptiveThreshold(blur, 255, cv2.ADAPTIVE_THRESH_MEAN_C,
                               cv2.THRESH_BINARY_INV, 15, 8)
    return th

def analyze_bubble_region(th, x,y,w,h):
    h_img, w_img = th.shape
    # clip coords
    x = max(0, min(x, w_img-1))
    y = max(0, min(y, h_img-1))
    w = max(1, min(w, w_img-x))
    h = max(1, min(h, h_img-y))
    roi = th[y:y+h, x:x+w]
    total = roi.size
    filled = cv2.countNonZero(roi)
    fill_ratio = filled / total
    return fill_ratio

def extract_answers_from_pdf(pdf_path, template_name='tyt_standard_A'):
    template = load_template(template_name)
    images = pdf_to_images(pdf_path)
    results = []
    for page_idx, pil_img in enumerate(images):
        img = pil_to_cv2(pil_img)
        th = preprocess(img)
        page_result = {}
        for q_no, coords in template['bubbles'].items():
            x,y,w,h = coords['x'], coords['y'], coords['w'], coords['h']
            fill = analyze_bubble_region(th, x,y,w,h)
            page_result[q_no] = {'fill': fill, 'is_filled': fill > THRESH_FILL}
        results.append(page_result)
    return results

if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print('Usage: python process_pdf.py <file.pdf>')
    else:
        out = extract_answers_from_pdf(sys.argv[1])
        print(out)
