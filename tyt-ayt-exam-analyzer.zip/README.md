# TYT-AYT Exam Analyzer

Bu repo, sınıf bazlı TYT/AYT deneme sınavlarını PDF olarak yükleyip otomatik/manuel değerlendirme yapabileceğiniz örnek bir uygulama içerir.
Backend: Flask
Frontend: React + Vite

## İçerik
- backend/: Flask uygulaması, OCR pipeline örneği, JWT auth quick-start
- frontend/: Vite + React örnek uygulaması (upload + list)
- templates/: Örnek bubble-sheet template

## Hızlı başlangıç (geliştirme)
### Backend
```
cd backend
python -m venv .venv
source .venv/bin/activate   # windows: .venv\Scripts\activate
pip install -r requirements.txt
python create_db.py
python app.py
```

### Frontend
```
cd frontend
npm install
npm run dev
```
