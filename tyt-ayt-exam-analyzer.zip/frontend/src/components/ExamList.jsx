import React, { useEffect, useState } from 'react'

export default function ExamList(){
  const [exams, setExams] = useState([])

  useEffect(()=>{
    fetch('http://localhost:5000/api/exams').then(r=>r.json()).then(setExams)
  },[])

  return (
    <div>
      <h3>Sınavlar</h3>
      <ul>
        {exams.map(e=> <li key={e.id}>{e.title} - {e.class_id} - {new Date(e.date).toLocaleString()}</li>)}
      </ul>
    </div>
  )
}
