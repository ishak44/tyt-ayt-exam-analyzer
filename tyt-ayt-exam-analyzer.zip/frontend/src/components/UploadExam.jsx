import React, { useState } from 'react'

export default function UploadExam(){
  const [file, setFile] = useState(null)
  const [title, setTitle] = useState('')
  const [classId, setClassId] = useState('')

  async function upload(e){
    e.preventDefault()
    if(!file) return alert('PDF seçiniz')
    const fd = new FormData()
    fd.append('file', file)
    fd.append('title', title)
    fd.append('class_id', classId)
    const res = await fetch('http://localhost:5000/api/exams', { method: 'POST', body: fd })
    const data = await res.json()
    alert('Yüklendi: ' + JSON.stringify(data))
  }

  return (
    <form onSubmit={upload}>
      <div>
        <input placeholder="Sınav adı" value={title} onChange={e=>setTitle(e.target.value)} />
      </div>
      <div>
        <input placeholder="Sınıf" value={classId} onChange={e=>setClassId(e.target.value)} />
      </div>
      <div>
        <input type="file" accept="application/pdf" onChange={e=>setFile(e.target.files[0])} />
      </div>
      <button type="submit">Yükle</button>
    </form>
  )
}
