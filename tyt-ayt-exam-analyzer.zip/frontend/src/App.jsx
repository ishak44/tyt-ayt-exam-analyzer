import React from 'react'
import UploadExam from './components/UploadExam'
import ExamList from './components/ExamList'

export default function App(){
  return (
    <div style={{padding:20}}>
      <h1>TYT-AYT Exam Analyzer (Demo)</h1>
      <UploadExam />
      <hr/>
      <ExamList />
    </div>
  )
}
